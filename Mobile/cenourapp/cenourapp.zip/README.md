# Cenourapp

Course Alura - Cordova e PhoneGap

Adobe PhoneGap Build - permite empacotar o app mobile na nuvem.